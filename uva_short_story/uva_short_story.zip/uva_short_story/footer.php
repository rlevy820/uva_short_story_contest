<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/styles.css">
    <title>Footer</title>
</head>
<style>
</style>
<body>
    <footer>
        <div class="footer">
            <center><p style="padding-top:15px;"><a class="namelink" target="_blank" href="https://www.linkedin.com/in/ryan-levy-93b442220/">Ryan Levy</a> &emsp; | &emsp; <a class="namelink" target="_blank" href="https://www.linkedin.com/in/samson-mccune-6739111b2/">Samson McCune</a><p></center>
            <center>McCune Entertainment LLC Writing Contest • 2023&emsp;&emsp;<a href="tos.php">Terms and Conditions</a>&emsp;|&emsp;<a href="mailto:fpp5kw@virginia.com, tcf5nc@virginia.com">Contact</a></center>
            <center><p style="padding-top:25px; padding-bottom:15px; font-size:10px;">This website is student created and maintained and is not an official publication of the University of Virginia communications department</p></center>
    </footer>
</body>
</html>

<style>
body {
    position: relative;
    min-height: 100vh;
    padding-bottom: 80px; /* Footer Height */
}
footer {
    background-color: #dddddd;
    color: #00337f;
    position: absolute;
    bottom: 0;
    width: 100%;
}
.namelink {
    text-decoration: none;
    color: black;
}
.namelink:hover {
    text-decoration: underline;
    color: blue;
}
</style>
